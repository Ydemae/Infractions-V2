import {vueInfListe} from "../controleur/class_inf_liste.js"
vueInfListe.init( { divTitre :document.querySelector('[id=div_inf_liste_titre]')
,btnAjouter :document.querySelector('[id=btn_inf_ajouter]')
,tableinfs :document.querySelector('[id=table_inf]')
});