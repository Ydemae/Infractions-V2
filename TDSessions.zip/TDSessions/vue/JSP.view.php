<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../vue/style/style.css">
        <title>File page</title>
    </head>
    <body>
        <section>
            <header>Page</header>
        </section>
        <div>
            <h1>Here goes nothing</h1>
        </div>
    </body>
</html>