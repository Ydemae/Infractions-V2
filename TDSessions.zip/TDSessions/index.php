<?php
header("location: ./controleur/login.php")

?>